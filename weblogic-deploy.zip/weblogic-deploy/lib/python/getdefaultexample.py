import yaml
# from wlsdeploy.aliases.aliases import Aliases
# from wlsdeploy.aliases.location_context import LocationContext
# import wlsdeploy.aliases.model_constants as FOLDERS

# location = LocationContext()
# location.append_location(FOLDERS.TOPOLOGY, FOLDERS.SERVER, 'AdminServer')
# aliases = Aliases(None)
# aliases.get_model_attribute_default_value(location, 'ListenPort')

myDict = yaml.load(open('example.yaml'))

if 'topology' in myDict:
    if 'Server' in myDict['topology']:
        if 'AdminServer' in myDict['topology']['Server']:
            if 'ListenPort' in myDict['topology']['Server']['AdminServer']:
                print 'AdminServer Listen Port is %s'%myDict['topology']['Server']['AdminServer']['ListenPort']


